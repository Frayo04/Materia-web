//LOGINNNNNNNN
if (document.getElementById('loginForm')) {
    const loginForm = document.getElementById('loginForm');

    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();

        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        // Simulación de login (solo validación básica)
        if (email && password) {
            // Guardar sesión simulada en localStorage
            localStorage.setItem('netfluxUser', email);

            // Redirigir a la página principal
            window.location.href = 'index.html';
        }
    });
}

// FUNCIONALIDADES DE LA PÁGINA PRINCIPAL

document.addEventListener('DOMContentLoaded', function() {

    // Si estamos en index.html
    if (document.querySelector('.navbar')) {

       
        // CAMBIO DE NAVBAR 
       
        const navbar = document.querySelector('.navbar');

        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

       
        // SLIDER DE ARRIBA
        
        const rowPosters = document.querySelectorAll('.row-posters');

        rowPosters.forEach(row => {
            let isDown = false;
            let startX;
            let scrollLeft;

            // Eventos para arrastrar con el maus
            row.addEventListener('mousedown', (e) => {
                isDown = true;
                startX = e.pageX - row.offsetLeft;
                scrollLeft = row.scrollLeft;
            });

            row.addEventListener('mouseleave', () => {
                isDown = false;
            });

            row.addEventListener('mouseup', () => {
                isDown = false;
            });

            row.addEventListener('mousemove', (e) => {
                if (!isDown) return;
                e.preventDefault();
                const x = e.pageX - row.offsetLeft;
                const walk = (x - startX) * 2;
                row.scrollLeft = scrollLeft - walk;
            });
        });

     
        // LINEA DE PELÍCULA
        
        const modal = document.getElementById('movieModal');
        const closeModalBtn = document.querySelector('.close-modal');
        const moviePosters = document.querySelectorAll('.movie-poster');

        // Abrir espacio al htocar en una película
        moviePosters.forEach(poster => {
            poster.addEventListener('click', function() {
                const title = this.dataset.title;
                const description = this.dataset.description;
                const genre = this.dataset.genre;
                const year = this.dataset.year;
                const movieId = this.dataset.id;

                // Actualizar contenido 
                document.getElementById('modalTitle').textContent = title;
                document.getElementById('modalDescription').textContent = description;
                document.getElementById('modalGenre').textContent = genre;
                document.getElementById('modalYear').textContent = year;

                //guarda id
                modal.dataset.currentMovie = movieId;

                // Verificar si está en Mi Lista
                updateMyListButton(movieId);

                // Mostrar modal
                modal.classList.add('active');
                document.body.style.overflow = 'hidden';
            });
        });

        // Cerrar espacio
        closeModalBtn.addEventListener('click', closeModal);

        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeModal();
            }
        });

        function closeModal() {
            modal.classList.remove('active');
            document.body.style.overflow = 'auto';
        }

        // Cerrar espacio con tecla ESC
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && modal.classList.contains('active')) {
                closeModal();
            }
        });

       
        // MI LISTA 
        
        const addToListBtn = document.getElementById('addToList');

        // Obtener películas de Mi Lista 
        function getMyList() {
            const myList = localStorage.getItem('netfluxMyList');
            return myList ? JSON.parse(myList) : [];
        }

        // Guardar película en Mi Lista
        function saveToMyList(movieId) {
            let myList = getMyList();
            if (!myList.includes(movieId)) {
                myList.push(movieId);
                localStorage.setItem('netfluxMyList', JSON.stringify(myList));
            }
        }

        // Eliminar película de Mi Lista
        function removeFromMyList(movieId) {
            let myList = getMyList();
            myList = myList.filter(id => id !== movieId);
            localStorage.setItem('netfluxMyList', JSON.stringify(myList));
        }

        // Verificar si una película está en Mi Lista
        function isInMyList(movieId) {
            const myList = getMyList();
            return myList.includes(movieId);
        }

        // Actualizar el botón de Mi Lista
        function updateMyListButton(movieId) {
            if (isInMyList(movieId)) {
                addToListBtn.textContent = '✓ En Mi Lista';
                addToListBtn.classList.add('added');
            } else {
                addToListBtn.textContent = '+ Mi Lista';
                addToListBtn.classList.remove('added');
            }
        }

        // Agregar y Quitar de Mi Lista
        addToListBtn.addEventListener('click', function() {
            const movieId = modal.dataset.currentMovie;

            if (isInMyList(movieId)) {
                removeFromMyList(movieId);
                addToListBtn.textContent = '+ Mi Lista';
                addToListBtn.classList.remove('added');

                // Eliminar indicador visual del flayer
                const poster = document.querySelector(`[data-id="${movieId}"]`);
                const indicator = poster.querySelector('.my-list-indicator');
                if (indicator) {
                    indicator.remove();
                }
            } else {
                saveToMyList(movieId);
                addToListBtn.textContent = '✓ En Mi Lista';
                addToListBtn.classList.add('added');

                // Agregar indicador visual al poster
                const poster = document.querySelector(`[data-id="${movieId}"]`);
                if (!poster.querySelector('.my-list-indicator')) {
                    const indicator = document.createElement('div');
                    indicator.className = 'my-list-indicator';
                    indicator.textContent = '✓';
                    poster.appendChild(indicator);
                }
            }
        });

       
        // CAMBIO DINÁMICO DE BANNER
       
        const hero = document.querySelector('.hero');
        const heroTitle = document.querySelector('.hero-title');
        const heroDescription = document.querySelector('.hero-description');

        // Al hacer clic en una película, cambiar el hero banner
        moviePosters.forEach(poster => {
            poster.addEventListener('dblclick', function() {
                const title = this.dataset.title;
                const description = this.dataset.description;
                const bgImage = this.style.backgroundImage;

                // Cambiar el contenido del hero
                heroTitle.textContent = title;
                heroDescription.textContent = description;
                hero.style.backgroundImage = `linear-gradient(to right, rgba(0,0,0,0.8), transparent), ${bgImage}`;

                // desliza suave hacia arriba
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        });

      
        // INICIALIZAR INDICADORES DE MI LISTA
      
        function initializeMyListIndicators() {
            const myList = getMyList();
            myList.forEach(movieId => {
                const poster = document.querySelector(`[data-id="${movieId}"]`);
                if (poster && !poster.querySelector('.my-list-indicator')) {
                    const indicator = document.createElement('div');
                    indicator.className = 'my-list-indicator';
                    indicator.textContent = '✓';
                    poster.appendChild(indicator);
                }
            });
        }

        // Ejecutar al cargar la página
        initializeMyListIndicators();

      
        // SIMULACIÓN DE REPRODUCCIÓN
       
        const playButtons = document.querySelectorAll('.btn-play, .btn-modal-play');

        playButtons.forEach(button => {
            button.addEventListener('click', function() {
                alert('🎬 Reproduciendo contenido...\n\n(Esto es una simulación educativa)');
            });
        });
    }
});
